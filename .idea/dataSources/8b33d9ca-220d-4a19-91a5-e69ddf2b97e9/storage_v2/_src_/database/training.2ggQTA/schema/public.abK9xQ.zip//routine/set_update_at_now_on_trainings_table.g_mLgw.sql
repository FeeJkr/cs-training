create function set_update_at_now_on_trainings_table() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.updated_at = now();

    RETURN NEW;
END;
$$;

alter function set_update_at_now_on_trainings_table() owner to "default";

